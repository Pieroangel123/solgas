<?php
session_start();

if($_SESSION["s_usuario"] === null){
    header("Location: ../index.php");
}

include("conexion_bd.php");
$con=conectar();

$sql="SELECT *  FROM mantener_glp";
$query=mysqli_query($con,$sql);

$row=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos5.css">
    <title>MantenerGLP</title>
</head>
<body>
    <div class="container">
        <div class='nav'>
            <div class='logo_img'><img src="../img/logo-solgas.png" alt=""></div>
            <ul class='nav_ul'>
            <li><a>Inicio</a></li>
                <li><a href='index.php'>Blog</a></li>
                <li><a href='campaña.php'>Campaña</a></li>
                <li><a href='vistaGLP.php'>vistaGLP</a></li>
                <li><a href='Form_Distributor.php'>Register</a></li>
                <li><a href='Form_RegistrarNoticia.php'>Registrar Noticia</a></li>
                <li><a href='MantenerGLP.php'>GLP</a></li>
                <li><a href='index2.php'>Maps</a></li>
                <li><a href='form_crud.php'>Gestion Pedidos</a></li>
                <li><a href='https://docs.google.com/forms/d/e/1FAIpQLSeJSOlhnsyqq5rFCRhsptTGz2lrPSWUZRe17EwWWl3N-jSBBg/viewform?usp=sf_link'>Encuesta Calidad</a></li>
            </ul>
        </div>
        
        <div class='container_form'>

              <table class="table" >
                                <thead class="table-success table-striped" >
                                    <tr>
                                    <th>CodGLP</th>
                    <th>Region</th>
                    <th>Tipo Kg</th>
                    <th>Precio</th>
                                    </tr>
                                </thead>

                                <tbody style="color: green">
                                        <?php
                                            while($row=mysqli_fetch_array($query)){
                                        ?>
                                            <tr>
                                            <th><?php echo $row['cod_GLP'];?></th>
                        <th><?php echo $row['cod_Region']; ?></th>
                        <th><?php echo $row['cod_tipoGLP'];?></th>
                        <th><?php echo $row['cod_Precio'];?></th>
                                                <th><a href="actualizar.php?id=<?php echo $row['cod_estudiante'] ?>" class="btn btn-info">Editar</a></th>
                                                <th><a href="delete.php?id=<?php echo $row['cod_estudiante'] ?>" class="btn btn-danger">Eliminar</a></th>                                        
                                            </tr>
                                        <?php 
                                            }
                                        ?>
                                </tbody>
                            </table>  
        </div>

</body>
</html>