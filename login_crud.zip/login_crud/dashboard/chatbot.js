button = document.getElementById('#button');
wrapper= documemt.querySelector('.wrapper');

button.addEventListener('click',()=>{
    wrapper.classList.toggle('active');
})