<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos3.css">
    <title>Grafica Usuario</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
</head>
<body>
    <div class="container">
        <div class='nav'>
            <div class='logo_img'><img src="../img/logo-solgas.png" alt=""></div>
            <ul class='nav_ul'>
                <li><a>Inicio</a></li>
                <li><a href='index.php'>Blog</a></li>
                <li><a href='campaña.php'>Campaña</a></li>
                <li><a href='grafica_usuario.php'>Actividad Usuarios</a></li>
                <li><a href='Form_Distributor.php'>Register</a></li>
                <li><a href='Form_RegistrarNoticia.php'>Registrar Noticia</a></li>
                <li><a href='MantenerGLP.php'>GLP</a></li>
                <li><a href='index2.php'>Maps</a></li>
                <li><a href='form_crud.php'>Gestion Pedidos</a></li>
                <li><a href='https://docs.google.com/forms/d/e/1FAIpQLSeJSOlhnsyqq5rFCRhsptTGz2lrPSWUZRe17EwWWl3N-jSBBg/viewform?usp=sf_link'>Encuesta Calidad</a></li>
            </ul>
        </div>
        <div class='nav_info'>
        <h1>Interacciones usuarios de SOLGAS</h1>
    <canvas id="grafica"></canvas>
    <script type="text/javascript" src="script.js"></script>          
        </div>
    
    </div>

    



</body>
</html>