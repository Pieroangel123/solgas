<?php
session_start();

if($_SESSION["s_usuario"] === null){
    header("Location: ../index.php");
}

include("conexion_bd.php");
$con=conectar();

$sql="SELECT *  FROM alumno";
$query=mysqli_query($con,$sql);

$row=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos2.css">
    <title>Formulario De Distribuidor</title>
    <style type="text/css">
        h1 {
            color: white;
        }

        .asd{
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class='nav'>
            <div class='logo_img'><img src="../img/logo-solgas.png" alt=""></div>
            <ul class='nav_ul'>
            <li><a>Inicio</a></li>
                <li><a href='index.php'>Blog</a></li>
                <li><a href='campaña.php'>Campaña</a></li>
                <li><a href='grafica_usuario.php'>Actividad Usuarios</a></li>
                <li><a href='Form_Distributor.php'>Register</a></li>
                <li><a href='Form_RegistrarNoticia.php'>Registrar Noticia</a></li>
                <li><a href='MantenerGLP.php'>GLP</a></li>
                <li><a href='index2.php'>Maps</a></li>
                <li><a href='form_crud.php'>Gestion Pedidos</a></li>
                <li><a href='https://docs.google.com/forms/d/e/1FAIpQLSeJSOlhnsyqq5rFCRhsptTGz2lrPSWUZRe17EwWWl3N-jSBBg/viewform?usp=sf_link'>Encuesta Calidad</a></li>
            </ul>
        </div>
        
        <div class="container mt-5">
                    <div class="row"> 
                        
                        <div class="col-md-8" id="asd">
                            <h1>Gestion de Ordenes SOLGAS</h1>
                                <form action="insertar.php" method="POST">
                                    
                                <select class="form-control mb-3" name="cod_estudiante" placeholder="cod estudiante">
                                        <option value="010601">Lima</option>
                                        <option value="010602">Chiclayo</option>
                                        <option value="010603">Arequipa</option>
                                    </select>
                                    <select class="form-control mb-3" name="dni" placeholder="cod estudiante">
                                        <option value="01060112">Premium</option>
                                        <option value="01060113">Medio</option>
                                        <option value="01060114">Economico</option>
                                    </select>
                                    <select class="form-control mb-3" name="nombres" placeholder="cod estudiante">
                                        <option value="ENTREGA RAPIDA">SOLGAS MAX</option>
                                        <option value="ENTREGA MEDIA">SOLGAS MEDIO</option>
                                        <option value="ENTREGA BAJA">SOLGAS</option>
                                    </select>
                                    <select class="form-control mb-3" name="apellidos" placeholder="cod estudiante">
                                        <option value="Shirley Tompson">Shirley Tompson</option>
                                        <option value="Piero Galindo">Piero Galindo</option>
                                        <option value="Diego">Diego</option>
                                    </select>
                                    
                                    <input type="submit" name="BtnGuardar" class="btn btn-primary">
                                </form>
                        </div>

                        <div class="col-md-6">
                            <table class="table" >
                                <thead class="table-success table-striped" >
                                    <tr>
                                        <th>CODIGO TURNO</th>
                                        <th>CODIGO CURSO</th>
                                        <th>NOMBRE CURSO</th>
                                        <th>DOCENTE</th>
                                        

                                    </tr>
                                </thead>

                                <tbody>
                                        <?php
                                            while($row=mysqli_fetch_array($query)){
                                        ?>
                                            <tr>
                                                <th><?php  echo $row['cod_estudiante']?></th>
                                                <th><?php  echo $row['dni']?></th>
                                                <th><?php  echo $row['nombres']?></th>
                                                <th><?php  echo $row['apellidos']?></th>    
                                                <th><a href="actualizar.php?id=<?php echo $row['cod_estudiante'] ?>" class="btn btn-info">Editar</a></th>
                                                <th><a href="delete.php?id=<?php echo $row['cod_estudiante'] ?>" class="btn btn-danger">Eliminar</a></th>                                        
                                            </tr>
                                        <?php 
                                            }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                    </div>  
            </div>

    </div>

       
    <script src="../jquery/jquery-3.3.1.min.js"></script>    
     <script src="../bootstrap/js/bootstrap.min.js"></script>    
     <script src="../popper/popper.min.js"></script>    
        
     <script src="../plugins/sweetalert2/sweetalert2.all.min.js"></script>    
     <script src="../codigo.js"></script>    
</body>
</html>