<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "root";
	$dbname = "bd_inscripcion";
	
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);