<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos3.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="//code.tidio.co/yxjwfclsvqkrpfnjwk13dm5cvyxomrxe.js" async></script>
    <title>Blog Informativo</title>
</head>
<body>
    <div class="container">
        <div class='nav'>
            <div class='logo_img'><img src="../img/logo-solgas.png" alt=""></div>
            <ul class='nav_ul'>
                <li><a>Inicio</a></li>
                <li><a href='index.php'>Blog</a></li>
                <li><a href='campaña.php'>Campaña</a></li>
                <li><a href='grafica_usuario.php'>Actividad Usuarios</a></li>
                <li><a href='Form_Distributor.php'>Register</a></li>
                <li><a href='Form_RegistrarNoticia.php'>Registrar Noticia</a></li>
                <li><a href='MantenerGLP.php'>GLP</a></li>
                <li><a href='index2.php'>Maps</a></li>
                <li><a href='form_crud.php'>Gestion Pedidos</a></li>
                <li><a href='usuarios.php'>Gestion usuarios</a></li>
                <li><a href='https://docs.google.com/forms/d/e/1FAIpQLSeJSOlhnsyqq5rFCRhsptTGz2lrPSWUZRe17EwWWl3N-jSBBg/viewform?usp=sf_link'>Encuesta Calidad</a></li>
            </ul>
        </div>
        <div class='nav_info'>
            <h1>BLOG - INFORMATIVO</h1>
            
        </div>
    
    </div>
    <div class=content_info id ='blog'>

        <div class="content_blog">
            <div class='info' category='lima'>
                <img src="../img/noticia1.jpg " alt="">
                <h3>Solgas amplió en 40% almacenamiento de su terminal de GLP en Lima</h3>
                <p>Según Solgas la construcción e instalación de la tercera esfera de GLP de la Terminal de Ventanilla demandó una inversión de más de US$ 15 millon...</p>
                <button>LEER MÁS</button>
                <inpu type="date" />
            </div>
            <div class='info' category='lima'>
                <img src="../img/noticia2.jpg" alt="">
                <h3>Solgas amplió en 40% almacenamiento de su terminal de GLP en Lima</h3>
                <p>Según Solgas la construcción e instalación de la tercera esfera de GLP de la Terminal de Ventanilla demandó una inversión de más de US$ 15 millon...</p>
                <button>LEER MÁS</button>
            </div>
            <div class='info' category='arequipa'>
                <img src="../img/noticia3.jpg" alt="">
                <h3>Solgas amplió en 40% almacenamiento de su terminal de GLP en Lima</h3>
                <p>Según Solgas la construcción e instalación de la tercera esfera de GLP de la Terminal de Ventanilla demandó una inversión de más de US$ 15 millon...</p>
                <button>LEER MÁS</button>
            </div>
            <div class='info' category='arequipa'>
                <img src="../img/noticia4.jpg" alt="">
                <h3>Solgas amplió en 40% almacenamiento de su terminal de GLP en Lima</h3>
                <p>Según Solgas la construcción e instalación de la tercera esfera de GLP de la Terminal de Ventanilla demandó una inversión de más de US$ 15 millon...</p>
                <button>LEER MÁS</button>
            </div>
        </div>
        <div class="content_categoria">
            <div id="date" class='date'></div>
            <h3>Región</h3>
            <ul class='categoria_ul'>
                <li id='lima' category='lima' class='item'>Lima </li>
                <li id='arequipa' category='arequipa' class='item'>Arequipa</li>
                <li id='tacna' category='tacna' class='item'>Tacna</li>
                <li id='piura' category='piura' class='item'>Piura</li>
                <li id='Cusco' category='cusco' class='item'>Cusco</li>
                <li id='Ayacucho' category='ayacucho' class='item'>Ayacucho</li>
            </ul>
        </div>
    </div>
    <div class="new_footer">
		<div class="cont-new_footer">
			<h3>ENLACES DE INTERÉS</h3>
			<ul>			
				<li><a href="Form_Distributor.php">¿Quieres ser distribuidor Solgas?</a></li>
				<li><a href="https://www.solgas.com.pe/contactenos/">Contáctenos</a></li>
				
				<li><a href="" class="uso_web-abrir">Condiciones de Uso de Página Web</a></li>
				<li><a href="" class="politica_priv-abrir" data-pop="contacto">Política de Protección de Datos Personales</a></li>
				
			</ul>
		</div>
		<div class="bnt_reclamaciones">
			<a href="https://librodereclamaciones.solgas.com.pe:8043/" target="_blank">
				<img src="https://www.solgas.com.pe/wp-content/themes/Tema_solgas/img/icono-libro-reclamaciones.jpg">	
			</a>
		</div>
	</div>
    <footer style="background: #ff8201">© Copyright Solgas - 2022 | Central Administrativa: <a href="tel:012157300" style="color: inherit;">(01) 215-7300</a> | Emergencias: <a href="tel:016133333" style="color: inherit;">(01) 613-3333</a></footer>
    <script>
        $(document).ready(function(){
            $("#send-btn").on("click", function(){
                $value = $("#data").val();
                $msg = '<div class="user-inbox inbox"><div class="msg-header"><p>'+ $value +'</p></div></div>';
                $(".form").append($msg);
                $("#data").val('');
                
                // start ajax code
                $.ajax({
                    url: 'message.php',
                    type: 'POST',
                    data: 'text='+$value,
                    success: function(result){
                        $replay = '<div class="bot-inbox inbox"><div class="icon"><i class="fas fa-user"></i></div><div class="msg-header"><p>'+ result +'</p></div></div>';
                        $(".form").append($replay);
                        // when chat goes down the scroll bar automatically comes to the bottom
                        $(".form").scrollTop($(".form")[0].scrollHeight);
                    }
                });
            });
        });
       let button = document.querySelector('.button');
       let wrapper= document.querySelector('.wrapper');

        button.addEventListener('click',()=>{
             wrapper.classList.toggle('active');
        })
    </script>
    <script src="../js/blog.js"></script>
    <script src="https://unpkg.com/scrollreveal"></scrip>
    <script>

        ScrollReveal().reveal('.info');
        date = new Date();
        year = date.getFullYear();
        month = date.getMonth() + 1;
        day = date.getDate();
        document.getElementById("date").innerHTML = month + "/" + day + "/" + year;
    </script>
</body>
</html>