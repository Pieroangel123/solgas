<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos4.css">
    <title>Crear Campaña</title>
</head>
<body>
    <div class="container">
        <div class='nav'>
            <div class='logo_img'><img src="../img/logo-solgas.png" alt=""></div>
            <ul class='nav_ul'>
            <li><a>Inicio</a></li>
                <li><a href='index.php'>Blog</a></li>
                <li><a href='campaña.php'>Campaña</a></li>
                <li><a href='grafica_usuario.php'>Actividad Usuarios</a></li>
                <li><a href='Form_Distributor.php'>Register</a></li>
                <li><a href='Form_RegistrarNoticia.php'>Registrar Noticia</a></li>
                <li><a href='MantenerGLP.php'>GLP</a></li>
                <li><a href='index2.php'>Maps</a></li>
                <li><a href='form_crud.php'>Gestion Pedidos</a></li>
                <li><a href='https://docs.google.com/forms/d/e/1FAIpQLSeJSOlhnsyqq5rFCRhsptTGz2lrPSWUZRe17EwWWl3N-jSBBg/viewform?usp=sf_link'>Encuesta Calidad</a></li>
            </ul>
        </div>
        
        <div class='container_form'>
            <form action="../bd/insert_Campaña.php" method='POST'>
               <div class="forma" id='step-1'>
                    <h1>Crear Campaña</h1>
                   <div class='forma_ul'>
                        <input type="text" name='cod_Titulo' placeholder="Titulo Campaña">
                        <input type="date" name='cod_Fecha' placeholder="Fecha de Campaña">
                        <input type="textarea" name='cod_Descripcion' placeholder="Descripcion">
                        
                        <select name='cod_Region'>
                            <option selected="true" disabled="disabled" >Region</option>
                            <option value='lima'>Lima</option>
                            <option value='arequipa'>Arequipa</option>
                            <option value='cusco'>Cusco</option>
                            <option value='piura'>Piura</option>
                        </select>
                        <input name="archivo" id="archivo" type="file"/>
                    </div>
                    <button class='submit button' id ='button' type="button" placeholder="Siguiente">Enviar</button>
                </div>
            </form>
        </div>

    </div>
    
</body>
</html>