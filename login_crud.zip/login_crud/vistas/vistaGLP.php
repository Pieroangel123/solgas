<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos5.css">
    <title>MantenerGLP</title>
</head>
<body>
    <div class="container">
        <div class='nav'>
            <div class='logo_img'><img src="../img/logo-solgas.png" alt=""></div>
            <ul class='nav_ul'>
                <li><a>Inicio</a></li>
                <li><a href='blog_informativo.php'>Blog</a></li>
                <li><a>Contacto</a></li>
                <li><a>Login</a></li>
                <li><a>Register</a></li>
            </ul>
        </div>
        
        <div class='container_form'>
           <table class='table'>
            <thead class='table-solgas'>
                <tr>
                    <th>CodGLP</th>
                    <th>Region</th>
                    <th>Tipo Kg</th>
                    <th>Precio</th>
                 </tr>
            </thead>
            <tbody>
                <?php 
                    // while($row = mysql_fetch_array($query)){
                ?>
                    <tr>
                        <th><?php echo $row['cod_GLP'];?></th>
                        <th><?php echo $row['cod_Region']; ?></th>
                        <th><?php echo $row['cod_tipoGLP'];?></th>
                        <th><?php echo $row['cod_Precio'];?></th>
                        <th><a class='button' href='MantenerGLP.php?id=<?php echo $row['cod_GLP']?>'> Editar </a></th>
                    <tr>
                <?php
                    // }
                ?>  
        </div>

</body>
</html>