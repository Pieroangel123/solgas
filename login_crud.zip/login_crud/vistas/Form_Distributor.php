<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos2.css">
    <title>Formulario De Distribuidor</title>
</head>
<body>
    <div class="container">
        <div class='nav'>
            <div class='logo_img'><img src="../img/logo-solgas.png" alt=""></div>
            <ul class='nav_ul'>
                <li><a>Inicio</a></li>
                <li><a href='blog_informativo.php'>Blog</a></li>
                <li><a href='campaña.php'>Campaña</a></li>
                <li><a href='index.php'>Login</a></li>
                <li><a href='Form_Distributor.php'>Register</a></li>
            </ul>
        </div>
        <div class='nav_info'>
            <div class='card'>
            <img src="../img/logo-solgas2.jpg" alt="">
            <img src="../img/logo-solgas3.jpg" alt="">
            </div>
        </div>
        <div class='container_form'>
            <form action="https://formsubmit.co/el/gpiero96@gmail.com" method='POST'>
               <div class="forma" id='step-1'>
                    <h1>DATOS PERSONALES</h1>
                   <div class='forma_ul'>
                        <input type="text" name='name' placeholder="Nombre y Apellido">
                        <input type="text" name='cod_Dni' placeholder="DNI">
                        <input type="text" name='cod_Telefono' placeholder="Teléfono Celular">
                        <input type="text" name='cod_Distrito' placeholder="Distrito">
                        <input type="text" name='cod_Departamento' placeholder="Departamento">
                        <input type="text" name='cod_Correo' placeholder="Coreo Electrónico">
                        <input type="text" name='cod_Edad' placeholder="Edad">
                        <input type="text" name='cod_Fecha' placeholder="Fecha de Naci">
                                            </div>
                    <button class='submit' id ='button' type="button" placeholder="Siguiente">Enviar</button>
                </div>
            </form>
        </div>

    </div>
    
</body>
</html>