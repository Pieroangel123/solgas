<?php
    // include('conexion.php');
    // $conexion = conectar();

    // $id=$_GET["id"];

    // $sql = "SELECT * FROM users WHERE cod_GLP= $id";
    // $query= mysqli_query($conexion, $sql);

    // $row= mysql_fetch_array($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos5.css">
    <title>MantenerGLP</title>
</head>
<body>
    <div class="container">
        <div class='nav'>
            <div class='logo_img'><img src="../img/logo-solgas.png" alt=""></div>
            <ul class='nav_ul'>
                <li><a>Inicio</a></li>
                <li><a href='blog_informativo.php'>Blog</a></li>
                <li><a>Contacto</a></li>
                <li><a>Login</a></li>
                <li><a>Register</a></li>
            </ul>
        </div>
        
        <div class='container_form'>
            <form action='updateGLP.php' method='POST'>
               <div class="forma" id='step-1'>
                    <h1>Editar Precio GLP</h1>
                   <div class='forma_ul'>
                        <input type="hidden" name="cod_GLP" value="<?php echo $row['cod_GLP'] ;?>">
                       
                       <select name='cod_Region'>
                           <option selected="true" disabled="disabled" >Region</option>
                           <option value='lima'>lima</option>
                           <option value='arequipa'>Arequipa</option>
                           <option value='cusco'>Cusco</option>
                           <option value='piura'>Piura</option>
                           <option value='amazonas'>Amazonas</option>
                           <option value='apurimac'>Apurimac</option>
                           <option value='ica'>Ica</option>
                           <option value='la libertad'>La Libertad</option>
                           <option value='loreto'>Loreto</option>
                           <option value='pUno'>PUno</option>
                           <option value='tacna'>Tacna</option>
                           <option value='tumbes'>Tumbes</option>
                        </select>
                        <select name='cod_TipoGLP'>
                           <option selected="true" disabled="disabled" >GLP kg</option>
                           <option value='GLP3kg'>GLP de 3 kg</option>
                           <option value='GLPde5kg'>GLP de 5 kg</option>
                           <option value='GLPde10kg'>GLP de 10 kg</option>
                           <option value='GLPde15kg'>GLP de 15 kg</option>
                           <option value='GLPde45kg'>GLP de 45 kg</option>
                        </select>
                        <input type="Number" name='cod_Precio' placeholder="Nuevo Precio">
                    </div>
                    <a class='button' href='publicarGLP.php'> Publicar </a>
                </div>
            </form>
        </div>

    </div>
    
</body>
</html>