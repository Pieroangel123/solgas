<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos2.css">
    <title>Formulario De Registro de Noticia</title>
</head>
<body>
    <div class="container">
        <div class='nav'>
            <div class='logo_img'><img src="../img/logo-solgas.png" alt=""></div>
            <ul class='nav_ul'>
                <li><a>Inicio</a></li>
                <li><a href='blog_informativo.php'>Blog</a></li>
                <li><a href='campaña.php'>Campaña</a></li>
                <li><a href='index.php'>Login</a></li>
                <li><a href='Form_Distributor.php'>Register</a></li>
            </ul>
        </div>

        <div class='container_form'>
            <form action="../bd/insert_Distributor.php" method='POST' action="/send.php" enctype="multipart/form-data">
               <div class="forma" id='step-1'>
                    <h1>Registrar Noticia</h1>
                   <div class='forma_ul'>
                        <input type="text" name='cod_TituloNoticia' placeholder="Titulo de la noticia">   
                    </div>
                    <div class='forma_ul'>
                        <input type="text" name='cod_FechaNoticia' placeholder="Fecha de la noticia">
                    </div>
                    <div class='forma_ul'>
                        <textarea class="form-control" aria-label="With textarea">Insertar contenido...</textarea>
                    </div>
                        <input type="file" name="cod_MultimediaNoticia" accept=".pdf,.jpg,.png" multiple />                    
                </div>
                        
            </form>
            <button class='submit' type="button" placeholder="Siguiente">PUBLICAR</button>
        </div>

    </div>
</body>
</html>