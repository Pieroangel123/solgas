<?php
include("conexion.php")
$conexion = Conectar();

$cod_Nombre =$_POST['cod_Nombre']; 
$cod_Dni =$_POST['cod_Dni']; 
$cod_Telefono =$_POST['cod_Telefono']; 
$cod_Distrito =$_POST['cod_Distrito']; 
$cod_Departamento =$_POST['cod_Departamento']; 
$cod_Correo =$_POST['cod_Correo']; 
$cod_Edad =$_POST['cod_Edad']; 
$cod_Fecha =$_POST['cod_Fecha']; 

$sql="INSERT INTO Distributor VALUES ('$cod_Nombre','$cod_Dni','$cod_Telefono',
                                    '$cod_Distrito','$cod_Departamento','$cod_Correo','$cod_Edad','$cod_Fecha')";
$query= mysqli_query($conexion.$sql);
if($query){
    header('location: Form_Distributor.php');
}else{

}