<?php

    include('conexion.php');
    $conexion = conectar();

    $cod_GLP = $_POST['cod_GLP'];
    $cod_region =$_POST['cod_region'];
    $cod_tipoGLP =$_POST['cod_tipoGLP'];
    $cod_Precio =$_POST['cod_precio'];

    $sql="UPDATE GLP SET cod_region = '$cod_region', cod_tipoGLP = '$cod_tipoGLP', cod_precio = '$cod_precio' WHERE cod_GLP = '$cod_GLP' ";
    $query = mysqli_query($conexion,$sql);

    
?>