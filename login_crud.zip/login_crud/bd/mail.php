<?php
 $destinatario = 'gpiero96@gmail.com'; // mail a enviar el mensaje
 
 $cod_Nombre =$_POST['cod_Nombre']; 
 $cod_Dni =$_POST['cod_Dni']; 
 $cod_Telefono =$_POST['cod_Telefono']; 
 $cod_Distrito =$_POST['cod_Distrito']; 
 $cod_Departamento =$_POST['cod_Departamento']; 
 $cod_Correo =$_POST['cod_Correo']; 
 $cod_Edad =$_POST['cod_Edad']; 
 $cod_Fecha =$_POST['cod_Fecha']; 

 $header = "SOLICITAR SER DISTRIBUIDOR";
 $mensaje = $mensaje . "\nAtentamente: " . $cod_Nombre . "\n DNI: " . $cod_Dni . "\n Telefono: " . $cod_Telefono . "\n Distrito: " . $cod_Distrito . "\n Departamento: " . $cod_Departamento . "\n Correo Personal: " . $cod_Correo . "\n Edad: " . $cod_Edad . "\n Fecha Solicitud: " . $cod_Fecha;
 
 mail($destinatario, $asunto, $mensaje , $header);
 echo "<script>alert('correo enviado exitosamente')</script>";
 echo "<script>setTimeout(\"location.href='blog_informativo.php'\",1000)</script>";

 ?>