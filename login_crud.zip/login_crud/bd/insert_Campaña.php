<?php
include("conexion.php")
$conexion = Conectar();

$cod_Titulo =$_POST['cod_Titulo']; 
$cod_Fecha =$_POST['cod_Fecha']; 
$cod_Descripciono =$_POST['cod_Descripcion']; 
$cod_Region =$_POST['cod_Region']; 
// falta extraer imagen 
$sql="INSERT INTO Distributor VALUES ('$cod_Titulo','$cod_Fecha','$cod_Descripcion',
                                    '$cod_Region)";
$query= mysqli_query($conexion.$sql);
if($query){
    header('location: campaña.php');
}else{

}